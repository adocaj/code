/********************************************************************************
 * The code in the files bkm.h, bkm.c and main.c are implementation of the      *
 * fixed K algorithm described in the following work:                           *
 *                                                                              *
 * Andris Docaj and Yu Zhuang,                                                  *
 * "Speeding Up Unsupervised Learning Through Early Stopping"                   * 
 *                                                                              *
 * The scripts are not guaranteed to be bug free, and were tested in a Linux    *
 * environment.                                                                 *
 ********************************************************************************/


//************************************************
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "bkm.h"
//************************************************

int main(int argc, char const *argv[])
{
    register int i, j, k; // loop variables

    int ndata = 2049280; int dim = 7; //* dataset info
    double kmeans_threshold = 5.0; //* used in the kmeans, stopping condition accuracy

    int kk = 16;
	
	clock_t start_t, end_t;
    double run_time;
    //--------- Here we create the path name of the dataset---
    char path_name[55]; char dataset_name[25];

    // we store the specific dataset name 
    strcpy(dataset_name, "household.txt");

    // the local Desktop path name
    strcpy(path_name, "household local data path");
    

    //* now we concatenate the full path name
    strcat(path_name, dataset_name);

    //------------------------------------------------

    int kmean_iters;
    
    int i0_in; int im_in; 
    double *data, *r_matrix, *data_new;
    int *cluster_assign; double *datum;
    double *cluster_center; double *cluster_radius; 
    int *cluster_start; int *cluster_size; double *cluster_ssd;

    double sse_total; // Total value of sum squared error

    FILE *file_p; 
    int status; // fscanf status when reading the data file
    int n; // keeps track of each value read by fscanf
    
    i0_in = 0; im_in = ndata; // the whole dataset
    
    data = (double *) malloc((long long) ndata * dim * sizeof(double)); // all the data values
    
    // open stream for reading
    file_p = fopen(path_name, "r");
    
    // Read the data
    n = 0;
    for ( status = fscanf(file_p, "%lf", &data[n]); 
    status != EOF && n < ndata * dim;
    status = fscanf(file_p, "%lf", &data[n]) ) {
        n++;
    }

    //************************************************************** 
    cluster_assign = (int *) calloc(ndata, sizeof(int)); 
    datum = (double *) malloc(dim * sizeof(double));

    //* allocate memory for the proper buffers
    cluster_center = (double *) calloc(kk*dim, sizeof(double));
    cluster_radius = (double *) calloc(kk, sizeof(double));
    cluster_start = (int *) calloc(kk, sizeof(int));
    cluster_size = (int *) calloc(kk, sizeof(int));
    cluster_ssd = (double *) calloc(kk, sizeof(double));

    // Call bkm
    start_t = clock();
    kmean_iters = bkm(kk, dim, i0_in, im_in, data, kmeans_threshold,
    cluster_assign, datum,
    cluster_center, cluster_radius, cluster_start, cluster_size, cluster_ssd);
	end_t = clock();

    run_time = (double) (end_t - start_t) / CLOCKS_PER_SEC;
    // Calculate the total sse
    sse_total = 0.0;
    for ( k = 0; k < kk; k++)
    {
        sse_total += cluster_ssd[k];
    }
    printf("\n***********************************\n");
	printf("Total elapsed time: %lf\n", run_time);
    printf("Total Error: %lf\n", sse_total); 
    printf("Total KMean Iterations: %d\n", kmean_iters);
    printf("\n***********************************\n");
    
    // close stream
    fclose(file_p);
    free(data); free(cluster_assign); free(datum);
    free(cluster_center); free(cluster_radius);
    free(cluster_start); free(cluster_size); free(cluster_ssd);
    
    return 0;
}

//**********----- End of main()-----**************************