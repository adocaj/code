#if !defined LIBKMEANS_H
#define LIBKMEANS_H

#define TRUE  1
#define FALSE 0

/********************************************************************************
 * The code in the files bkm.h, bkm.c and main.c are implementation of the      *
 * CH-Index algorithm described in the following work:                          *
 *                                                                              *
 * Andris Docaj and Yu Zhuang,                                                  *
 * "Speeding Up Unsupervised Learning Through Early Stopping"                   * 
 *                                                                              *
 * The scripts are not guaranteed to be bug free, and were tested in a Linux    *
 * environment.                                                                 *
 ********************************************************************************/

//*-----------------------------------------------------------------------------------
/*************************************************************************
 * Input:                                                                *
 *       dim - dimension of a data point                                 *
 *       datum1 - pointer to the first data point                        *
 *       datum2 - pointer to the second data point                       *
 * Output:                                                               *
 *       euclidean distance squared between datum1 and datum2            *
 *************************************************************************/
double calc_dist_square(int dim, double *datum1, double *datum2);
//*-----------------------------------------------------------------------------------

//*-----------------------------------------------------------------------------------
/*************************************************************************
 * array sizes:                                                          *
 *       cluster_assign[ndata], datum[dim], center[2*dim]                *
 * Input:                                                                *
 *       dim - dimension of each data point                              *
 *       i0 - first data point                                           *
 *       im - last data point                                            *
 *       data - pointer to the whole dataset                             *
 *       threshold - accuracy of calculation, determines stopping        *
 *                   of optimum centroid finding loop.                   *
 *       center[0] - centroid of the cluster                             *
 *       radius_pt[0] - farthest pt to the centroid                      *
 * Output:                                                               *
 *       radius_pt, center, start, size, ssd                             *
 * buffers: cluster_assign[], datum, center0[]                           *
 * radius_pt[2*dim]: - the radius pt of the cluster[k]                   *
 *************************************************************************/
int two_means(int dim, int i0, int im, double *data, double threshold,  // input 
    int *cluster_assign, double *datum, double *center0,                // buffers 
    double *radius_pt, double *center, int start[2], int size[2], double ssd[2]);
//*-----------------------------------------------------------------------------------
/*************************************************************************
 * array sizes:                                                          *
 *       cluster_assign[ndata], datum[dim], center[2*dim]                *
 * Input:                                                                *
 *       kk - number of clusters                                         *
 *       dim - dimension of each data point                              *
 *       i0_in - first data point                                        *
 *       im_in - last data point                                         *
 *       data - pointer to the whole dataset                             *
 *       threshold - accuracy of calculation, determines stopping        *
 *                   of optimum centroid finding loop.                   *
 * Output:                                                               *
 *       cluster_center, cluster_radius, cluster_start,                  *
 *       cluster_size, cluster_ssd                                       *
 * buffers: cluster_assign[], datum                                      *
 * radius_pt[2*dim]: - the radius pt of the cluster[k]                   *
 *************************************************************************/
//*-----------------------------------------------------------------------------------
int bkm(int kk, int dim, int i0_in, int im_in, double *data, double threshold, // input
        int *cluster_assign, double *datum,                                    // buffers
        double *cluster_center, double *cluster_radius, 
        int *cluster_start, int *cluster_size, double *cluster_ssd);
//*-----------------------------------------------------------------------------------

//*-----------------------------------------------------------------------------------
/******************************************************************************
 kk : number of clusters, i.e. the K in K-mean.
 cluster_center[kk*dim]: input  -- stores initial kk centers
                         output -- stores kk centers
 cluster_radius[kk]:output -- the radius of each output cluster
 cluster_start[kk]: output -- the index of the 1st in each cluster
 cluster_size[kk]:  output -- the num of data points in each cluster               
*******************************************************************************/
/*************************************************************************
 * array sizes:                                                          *
 *       cluster_assign[ndata], datum[dim], center[2*dim]                *
 * Input:                                                                *
 *       kk - number of clusters                                         *
 *       dim - dimension of each data point                              *
 *       i0_in - first data point                                        *
 *       im_in - last data point                                         *
 *       data - pointer to the whole dataset                             *
 *       threshold - accuracy of calculation, determines stopping        *
 *                   of optimum centroid finding loop.                   *
 * Output:                                                               *
 *       cluster_center, cluster_radius, cluster_start,                  *
 *       cluster_size, cluster_ssd                                       *
 * buffers: cluster_assign[], datum                                      *
 * radius_pt[2*dim]: - the radius pt of the cluster[k]                   *
 *************************************************************************/
int kmeans(int kk, int dim, int i0, int im, double *data, double threshold, // input
    int *cluster_assign, double *datum, double *cluster_center0,            // buffers
    double *radius_pt, double *cluster_center, double *cluster_radius,      // output
       int *cluster_start, int *cluster_size, double *cluster_ssd);         // output

//*----------------------------------------------------------------------------------- 

#endif
