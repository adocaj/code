/****** File: bkm.c ******/
/********************************************************************************
 * The code in the files bkm.h, bkm.c and main.c are implementation of the      *
 * Ray-Turi algorithm described in the following work:                          *
 *                                                                              *
 * Andris Docaj and Yu Zhuang,                                                  *
 * "Speeding Up Unsupervised Learning Through Early Stopping"                   *                                                                  
 *                                                                              *
 * The scripts are not guaranteed to be bug free, and were tested in a Linux    *
 * environment.                                                                 *
 ********************************************************************************/

#include "bkm.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>


//************************************************************************
/*************************************************************************
 * Input:                                                                *
 *       dim - dimension of a data point                                 *
 *       datum1 - pointer to the first data point                        *
 *       datum2 - pointer to the second data point                       *
 * Output:                                                               *
 *       euclidean distance squared between datum1 and datum2            *
 *************************************************************************/
double calc_dist_square(int dim, double *datum1, double *datum2) {
   int    i;
   double tmp, dist = 0.0;

   for(i=0; i<dim; i++) { tmp = datum1[i]-datum2[i] ;   dist += tmp*tmp ; }
   return dist;   /* Square of Euclidean distance */
}  

/*************************************************************************
 * array sizes:                                                          *
 *       cluster_assign[ndata], datum[dim], center[2*dim]                *
 * Input:                                                                *
 *       dim - dimension of each data point                              *
 *       i0 - first data point                                           *
 *       im - last data point                                            *
 *       data - pointer to the whole dataset                             *
 *       threshold - accuracy of calculation, determines stopping        *
 *                   of optimum centroid finding loop.                   *
 *       center[0] - centroid of the cluster                             *
 *       radius_pt[0] - farthest pt to the centroid                      *
 * Output:                                                               *
 *       radius_pt, center, start, size, ssd                             *
 * buffers: cluster_assign[], datum, center0[]                           *
 * radius_pt[2*dim]: - the radius pt of the cluster[k]                   *
 *************************************************************************/
int two_means(int dim, int i0, int im, double *data, double threshold,  // input 
            int *cluster_assign, double *datum, double *center0,              // buffers 
            double *radius_pt, double *center, int start[2], int size[2], double ssd[2])
{
   int    i, j, k, i_max, iterations, change, offset,
          start0, start1, end0, end1 ;
   double tmp, dist_max, dist;
   double dist_sq[2];
    
    double sse[2];
    int stop_loop;
   
   for(j=0;j<dim;j++) {/*** Choosing initial pair of centers ***/
      center[dim+j] = radius_pt[j] ;
      center[j] = 2.0*center[j] - radius_pt[j] ;
   } /*** End of choosing initial pair of centers ***/

    sse[0] = 0.0; sse[1] = 0.0;
    stop_loop = FALSE;
   iterations = 0;
   while( !stop_loop ) // loop stops when threshold is met
   { 
      iterations++;

      size[0]=0 ;   size[1]=0 ;
      for(j=0;j<dim;j++) {
         center0[j]    = center[j] ;
         center0[dim+j]= center[dim+j];
         center[j]=0.0;  center[dim+j]=0.0;
      }

      for(i=i0; i<im; i++) {
         dist_sq[0] = calc_dist_square(dim, data+i*dim, center0);
         dist_sq[1] = calc_dist_square(dim, data+i*dim, center0+dim);
         k = ((dist_sq[0] < dist_sq[1]) ? 0 : 1 ) ;
         sse[1] += dist_sq[k];
         cluster_assign[i] = k ;
         size[k]++ ;
         for(j=0; j<dim; j++) center[k*dim+j] += data[i*dim+j]; 
      } /****** Now, each data point has been assigned to a cluster ******/

      if(size[0] > 0) 
         for(j=0; j<dim; j++) 
            center[j] /= (double) size[0];
      if(size[1] > 0)
         for(j=0; j<dim; j++) 
            center[dim+j] /= (double) size[1] ;

      //* here we create the stop condition
      if (sse[0] != 0)
      {
         if( 100.0 * ( 1.0 - ( (double) sse[1] / sse[0] ) ) <=  threshold ) 
               stop_loop = TRUE;
      }
      
      sse[0] = sse[1]; // back the data up
      sse[1] = 0.0; // prepare it for the next run

   }/****** End of while(threshold met) ******/


   /****** Data Re-ordering ******/
   start[0]=i0;       start[1] = i0+size[0];
   start0= start[0];  end0 = start0 + size[0] ;
   start1= start[1];  end1 = start1 + size[1] ;
   while(start0 < end0) {/*** end0 and end1 MUST NOT EXCEED im ***/
      while( (start0<end0) && (cluster_assign[start0]==0) ) start0++ ;
      while( (start1<end1) && (cluster_assign[start1]==1) ) start1++ ;
      if( (start0<end0) && (start1<end1) ) {
         memcpy(datum, data+start0*dim, dim*sizeof(double)) ;
         memcpy(data+start0*dim, data+start1*dim, dim*sizeof(double)) ;
         memcpy(data+start1*dim, datum, dim*sizeof(double)) ;
         cluster_assign[start0] = 0;
         cluster_assign[start1] = 1;
         start0++;   start1++;
      }
      else if( (start0<end0)&&(start1==end1) ) {
         printf("Error: start0<end0 && start1==end1\n");   return 0;
      }
      else if( (start0==end0)&&(start1<end1) ) {
         printf("Error: start0==end0 && start1<end1\n");   return 0;
      }
      else {;}
   }/*** End of Data Re-ordering ***/

   /****** Compute sse[k] and radius_pt[k] ******/
   ssd[0]= 0.0 ;    ssd[1] = 0.0 ;
   for(k=0; k<2; k++) {
      dist = 0.0 ; /*** dist holds radius of the cluster ***/
      for(i=start[k]; i<start[k]+size[k]; i++) {
         tmp = calc_dist_square(dim, data+i*dim, center+k*dim) ;
         ssd[k] += tmp;
         if(dist < tmp) { 
            dist=tmp;    memcpy(radius_pt+k*dim, data+i*dim, dim*sizeof(double));
         }
      }
   }

   return iterations ;
} /****************** End of function two_means() ******************/


/*************************************************************************
 * array sizes:                                                          *
 *       cluster_assign[ndata], datum[dim], center[2*dim]                *
 * Input:                                                                *
 *       kk - number of clusters                                         *
 *       dim - dimension of each data point                              *
 *       i0_in - first data point                                        *
 *       im_in - last data point                                         *
 *       data - pointer to the whole dataset                             *
 *       threshold - accuracy of calculation, determines stopping        *
 *                   of optimum centroid finding loop.                   *
 * Output:                                                               *
 *       cluster_center, cluster_radius, cluster_start,                  *
 *       cluster_size, cluster_ssd                                       *
 * buffers: cluster_assign[], datum                                      *
 * radius_pt[2*dim]: - the radius pt of the cluster[k]                   *
 *************************************************************************/
int bkm(int kk, int dim, int i0_in, int im_in, double *data, double threshold, // input
         int *cluster_assign, double *datum,                                    // buffers
         double *cluster_center, double *cluster_radius, 
         int *cluster_start, int *cluster_size, double *cluster_ssd)
{
   
   int    i, j, k, k_max, nclusters, start[2], size[2] ;
   int i0, im;
   int iterations_tot;
   double tmp, dist_max, dist, ssd_initial, ssd[2], 
          *center, *radius_pt, *cluster_center0, *cluster_radius_pt ;

   //***************************************************************
   center  = (double *) calloc((2*dim), sizeof(double)) ;
   radius_pt=(double *) calloc((2*dim), sizeof(double)) ;
   cluster_center0  = (double *) calloc((kk*dim), sizeof(double)) ;
   cluster_radius_pt =(double *) calloc((kk*dim), sizeof(double)) ;
   //***************************************************************

/*** Compute centroid of the whole dataset ***/
   memset(cluster_center, 0.0, kk*dim*sizeof(double)) ;
   for(i=i0_in; i<im_in; i++)
      for(j=0; j<dim; j++) cluster_center[j] += (1.0 / (im_in-i0_in)) * data[i*dim+j];
/*** End of computing centroid of the whole dataset ***/ 

/*** Compute farthest pt to centroid. Store it in radius_pt[0] ***/
   memset(cluster_radius, 0.0, kk*sizeof(double)) ;
   for(i=i0_in; i<im_in; i++) {
      tmp = calc_dist_square(dim, data+i*dim, cluster_center) ;
      if(cluster_radius[0] < tmp) { 
         cluster_radius[0] = tmp ;
         memcpy(cluster_radius_pt, data+i*dim, dim*sizeof(double)) ;
      }
   }/*** End of computing farthest pt to centroid ***/

   iterations_tot = 0;

   memset(cluster_ssd, 0.0, kk*sizeof(double)) ;
   two_means(dim, i0_in, im_in, data, threshold,
             cluster_assign, datum, cluster_center0,
             cluster_radius_pt,cluster_center,cluster_start,cluster_size,cluster_ssd) ;
   nclusters = 2 ;

   while( nclusters < kk ) {
      tmp = 0.0 ;
      for(k=0; k<nclusters; k++) {  /* Find cluster with largest ssd */
         if( cluster_ssd[k] > tmp ) { tmp=cluster_ssd[k]; k_max=k; }
      }

      /*** Split the cluster into 2 clusters ***/
      i0 = cluster_start[k_max];
      im = i0 + cluster_size[k_max];
      for(j=0;j<dim;j++) radius_pt[j]= cluster_radius_pt[k_max*dim+j] ;
      for(j=0;j<dim;j++) center[j]   = cluster_center[k_max*dim+j] ;
      two_means(dim, i0, im, data, threshold,
                cluster_assign, datum, cluster_center0,
                radius_pt, center, start, size, ssd) ;

      cluster_start[k_max]  = start[0] ;
      cluster_start[nclusters]= start[1] ;
      cluster_size[k_max]  = size[0] ;
      cluster_size[nclusters]= size[1] ;
      cluster_ssd[k_max]  = ssd[0] ;
      cluster_ssd[nclusters]= ssd[1] ;
      memcpy(cluster_radius_pt+k_max*dim,    radius_pt,    dim*sizeof(double));
      memcpy(cluster_radius_pt+nclusters*dim,radius_pt+dim,dim*sizeof(double));
      memcpy(cluster_center + k_max*dim,     center,     dim*sizeof(double)) ;
      memcpy(cluster_center + nclusters*dim, center+dim, dim*sizeof(double)) ;
      nclusters++;
   } /************ End of while() loop ************/

   for(k=0; k<nclusters; k++) {
      if(cluster_size[k] == 0) { printf("AAA: in bkmeans: cluster %d empty!\n", k); }
   }
   if(nclusters != kk) printf("bkmeans(): nclusters=%d, kk=%d\n", nclusters, kk) ;

   if(nclusters > 2) {
      iterations_tot = kmeans(kk, dim, i0_in, im_in, data, threshold,
                  cluster_assign, datum, cluster_center0, cluster_radius_pt,
                  cluster_center,cluster_radius,cluster_start,cluster_size,cluster_ssd);
   }

   free(center); free(radius_pt);  free(cluster_center0); free(cluster_radius_pt);
   return iterations_tot ;
} /*********** End of function bkm() ***********/

/******************************************************************************
 kk : number of clusters, i.e. the K in K-mean.
 cluster_center[kk*dim]: input  -- stores initial kk centers
                         output -- stores kk centers
 cluster_radius[kk]:output -- the radius of each output cluster
 cluster_start[kk]: output -- the index of the 1st in each cluster
 cluster_size[kk]:  output -- the num of data points in each cluster               
*******************************************************************************/
/*************************************************************************
 * array sizes:                                                          *
 *       cluster_assign[ndata], datum[dim], center[2*dim]                *
 * Input:                                                                *
 *       kk - number of clusters                                         *
 *       dim - dimension of each data point                              *
 *       i0_in - first data point                                        *
 *       im_in - last data point                                         *
 *       data - pointer to the whole dataset                             *
 *       threshold - accuracy of calculation, determines stopping        *
 *                   of optimum centroid finding loop.                   *
 * Output:                                                               *
 *       cluster_center, cluster_radius, cluster_start,                  *
 *       cluster_size, cluster_ssd                                       *
 * buffers: cluster_assign[], datum                                      *
 * radius_pt[2*dim]: - the radius pt of the cluster[k]                   *
 *************************************************************************/
int kmeans(int kk, int dim, int i0, int im, double *data, double threshold,
           int *cluster_assign, double *datum, double *cluster_center0, double *radius_pt, 
           double *cluster_center, double *cluster_radius, 
              int *cluster_start, int *cluster_size, double *cluster_ssd)
{  
   int i, j, k, k_max, iterations, membership, start0, end0, start1, end1,
       position, *cluster_size0, *radius_index, k_max_used, nclusters ;
   double  tmp, dist_min ;

   double sse[2]; // sum squared errors 
   int stop_loop; // used to stop the while loop if the centroids meet the threshold condition


   nclusters = kk ;
   cluster_size0 = (int *) calloc(kk, sizeof(int)) ;
   radius_index  = (int *) calloc(kk, sizeof(int)) ;

  /****** Start of k-means iterations ******/
   iterations = 0 ;
   sse[0] = 0.0; sse[1] = 0.0;

   stop_loop = FALSE;
   while( !stop_loop ) {

      iterations++ ;

      for(k=0; k<kk; k++) {
         cluster_size0[k] = cluster_size[k] ;
         cluster_size[k]=0 ;
         cluster_radius[k]=0.0;
         for(j=0;j<dim;j++) cluster_center0[k*dim+j]=cluster_center[k*dim+j];
         for(j=0;j<dim;j++) cluster_center[k*dim+j] = 0.0 ;
      }

      for(i=i0; i<im; i++) {
         dist_min = 987654321012345.0 ; /* Find closest center to datum */
         for(k=0; k<kk; k++) {
            if(cluster_size0[k]>0) {
               tmp = calc_dist_square(dim, data+i*dim, cluster_center0+k*dim);
               if(tmp < dist_min) { membership=k ;    dist_min=tmp ; }
            }
         }
         sse[1] += dist_min; //* Calculate the total SSE

         cluster_assign[i] = membership ;
         cluster_size[membership]++ ;
         for(j=0;j<dim;j++) cluster_center[membership*dim+j] += data[i*dim+j];
         if(dist_min > cluster_radius[membership]) {
            cluster_radius[membership] = dist_min ;
            radius_index[membership] = i ;
            memcpy(radius_pt+membership*dim, data+i*dim, dim*sizeof(double));
         }
      }/*** Each data item has been assigned to a cluster ***/

      k_max=0;   tmp=cluster_radius[0];
      for(k=1; k<kk; k++) { /*** Find the cluster with the largest radius ***/
         if(tmp<cluster_radius[k]){ k_max=k; tmp=cluster_radius[k];}
      }
      k_max_used = 0 ;
      for(k=0; k<kk; k++) {
         if(cluster_size[k] > 0) 
            for(j=0;j<dim;j++) cluster_center[k*dim+j] /= (double)cluster_size[k];
         else if(!k_max_used) {
            k_max_used = 1 ;
            i = radius_index[k_max] ;

            cluster_size[k_max]--;
            cluster_size[k]++ ;
            cluster_assign[i] = k ;
            memcpy(cluster_center+k*dim, radius_pt+k_max*dim, dim*sizeof(double));
         }
      }

      //* here we create the stop condition
      if (sse[0] != 0)
      {
         if( 100.0 * ( 1.0 - ( (double) sse[1] / sse[0] ) ) <=  threshold ) 
               stop_loop = TRUE;
      }
      
      sse[0] = sse[1]; // back the data up
      sse[1] = 0.0; // prepare it for the next run

   }/*** End of while() loop ***/


/****** Data Re-ordering ******/
   position = 0 ;
   for(k=0;k<kk;k++) { cluster_start[k]=position;   position += cluster_size[k]; }
   for(k=0; k<kk-1; k++) {
      start0= cluster_start[k] ;
      end0  = start0 + cluster_size[k];
      start1= cluster_start[k+1];
      while(start0 < end0) {
         while((start0<end0)&&(cluster_assign[start0]==k)) start0++ ;
         if(start0<end0) {
            while((start1<im)&&(cluster_assign[start1]!=k)) start1++ ;
            if(start1==im) { printf("\nError: start1==im.\n");   return 0; }
            memcpy(datum, data+start0*dim, dim*sizeof(double)) ;
            memcpy(data+start0*dim, data+start1*dim, dim*sizeof(double)) ;
            memcpy(data+start1*dim, datum, dim*sizeof(double)) ;
            cluster_assign[start1] = cluster_assign[start0] ;
            cluster_assign[start0] = k;
            start0++;   start1++;
         }
      }
   }/****** End of loop for(k=0; k<kk-1; k++). End of Data Re-ordering ******/

   int num_empty = 0 ;
   for(k = 0; k < kk; k++) {/*** Calculate sse, radius, filter out empty clusters  ***/
      if(cluster_size[k]==0) { num_empty++ ;    nclusters-- ; }
      else {
         cluster_ssd[k] = 0.0 ;        cluster_radius[k]=0.0;
         start0 = cluster_start[k] ;   end0 = start0 + cluster_size[k] ;
         for(i=start0; i<end0; i++) {
            tmp = calc_dist_square(dim, data+i*dim, cluster_center+k*dim) ;
            if(tmp > cluster_radius[k]) cluster_radius[k] = tmp ;
            cluster_ssd[k] += tmp ;
         }
         if(num_empty > 0) {
            cluster_start[k-num_empty] = cluster_start[k] ;
            cluster_size[k-num_empty]  = cluster_size[k] ;
            memcpy(cluster_center+(k-num_empty)*dim, cluster_center+k*dim, dim*sizeof(double)) ;
            cluster_radius[k-num_empty]= cluster_radius[k] ;
            cluster_ssd[k-num_empty]   = cluster_ssd[k] ;
         }
      }
   }

   free(cluster_size0) ;   free(radius_index) ;
   return iterations ;
} /*********** End of function kmeans() ***********/


/*************************************************************************
 * Input:                                                                *
 *       A random number between 0 and 1                                 *
 * Output:                                                               *
 *       Achlioptas output                                               *
 *************************************************************************/
double r_i_j(double r_num){
    if (r_num <= (1.0 / 6))
    {
        return sqrt(3.0);
    }
    else if ((1.0 / 6) < r_num && r_num <= (1.0 / 3))
    {
        return -1.0 * sqrt(3.0);
    }
    else {
        return 0.0;
    }
}/*********** End of function r_i_j() ***********/

/*************************************************************************
 * Input:                                                                *
 *       dim - dimension of a data point                                 *
 *       vec_1 - pointer to the first vector                             *
 *       vec_2 - pointer to the second vector                            *
 * Output:                                                               *
 *       dot product between datum1 and datum2                           *
 *************************************************************************/
double dot_prod(double *vec_1, double *vec_2, int dim) {
    int i;
    double sum = 0.0;
    for ( i = 0; i < dim; i++)
    {
        sum += ( vec_1[i] * vec_2[i] );
    }
    return sum;
}/*********** End of function dot_prod() ***********/

/****************** End of File bkm.c ******************/
