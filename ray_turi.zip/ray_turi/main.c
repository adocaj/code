/********************************************************************************
 * The code in the files bkm.h, bkm.c and main.c are implementation of the      *
 * Ray-Turi algorithm described in the following work:                          *
 *                                                                              *
 * Andris Docaj and Yu Zhuang,                                                  *
 * "Speeding Up Unsupervised Learning Through Early Stopping"                   *
 *                                                                              *
 * The scripts are not guaranteed to be bug free, and were tested in a Linux    *
 * environment.                                                                 *
 ********************************************************************************/


//************************************************
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "bkm.h"
//************************************************

int main(int argc, char const *argv[])
{
    register int i, j, k; // loop variables

    int ndata = 2049280; int dim = 7; //* dataset info
    double kmeans_threshold = 0.0; //* used in the kmeans, stopping condition accuracy
    
    int kk;
	
	clock_t start_t, end_t;
    double run_time;
    //--------- Here we create the path name of the dataset---
    char path_name[55]; char dataset_name[25];

    // we store the specific dataset name 
    strcpy(dataset_name, "household.txt");

    // the local Desktop path name
    strcpy(path_name, "household local data path");
    

    //* now we concatenate the full path name
    strcat(path_name, dataset_name);

    //------------------------------------------------

    int kk_max;
    int total_iterations, kmean_iters;
    
    double intra, inter, temp_dist, min_cl_dist, validity;

    int i0_in; int im_in; 
    double *data, *r_matrix, *data_new;
    int *cluster_assign; double *datum;
    double *cluster_center; double *cluster_radius; 
    int *cluster_start; int *cluster_size; double *cluster_ssd;

    double sse_total; // Total value of sum squared error

    FILE *file_p; 
    int status; // fscanf status when reading the data file
    int n; // keeps track of each value read by fscanf
    
    i0_in = 0; im_in = ndata; // the whole dataset
    
    //**************************************************************
    //**--- This section of the code applies random projections
    unsigned seed = 123456789; // create seed for random projection matrix
    int dim_new = 3; // the dimension we will reduce to
    if (dim <= dim_new) { printf("The projecting dimension must be less than the original.\n"); exit(0);}
    // generate the r matrix
    r_matrix = (double *) malloc(dim * dim_new * sizeof(double));
    srand(seed);
    for ( i = 0; i < dim_new; i++)
    {
        for ( j = 0; j < dim; j++)
        {
            r_matrix[i * dim_new + j] = r_i_j((double) rand() / RAND_MAX);
        }
    }
    //**--- End of random projections
    //**************************************************************
    
    data = (double *) malloc((long long) ndata * dim * sizeof(double)); // all the data values
    
    // open stream for reading
    file_p = fopen(path_name, "r");
    
    // Read the data
    n = 0;
    for ( status = fscanf(file_p, "%lf", &data[n]); 
    status != EOF && n < ndata * dim;
    status = fscanf(file_p, "%lf", &data[n]) ) {
        n++;
    }

    //**************************************************************

    // project data using the r matrix
    data_new = (double *) malloc(ndata * dim_new * sizeof(double));
    for ( i = 0; i < ndata; i++)
    {
        for ( j = 0; j < dim_new; j++)
        {
            data_new[i * dim_new + j] = dot_prod(data + i*dim, r_matrix + j*dim, dim);
        }
    }

    // close stream
    fclose(file_p);
    free(data);
    //************************************************************** 
    cluster_assign = (int *) calloc(ndata, sizeof(int)); 
    datum = (double *) malloc(dim_new * sizeof(double));

    kk = 2; // start cluster number
    kk_max = 15; // end cluster number
    total_iterations = 0; // the total number of k_mean iterations
	
	start_t = clock();    
    while( kk <= kk_max )
    {
        // allocate memory for the proper buffers
        memset(cluster_assign, 0, ndata * sizeof(int));
        cluster_center = (double *) calloc(kk*dim_new, sizeof(double));
        cluster_radius = (double *) calloc(kk, sizeof(double));
        cluster_start = (int *) calloc(kk, sizeof(int));
        cluster_size = (int *) calloc(kk, sizeof(int));
        cluster_ssd = (double *) calloc(kk, sizeof(double));

        // Call bkm
        kmean_iters = bkm(kk, dim_new, i0_in, im_in, data_new, kmeans_threshold,
        cluster_assign, datum,
        cluster_center, cluster_radius, cluster_start, cluster_size, cluster_ssd);

        // Calculate the total sse
        sse_total = 0.0;
        for ( k = 0; k < kk; k++)
        {
            sse_total += cluster_ssd[k];
        }

        total_iterations += kmean_iters;

        // Calculate, intra and inter quantities
        intra = (1.0 / kk) * sse_total;

        min_cl_dist = calc_dist_square(dim_new, cluster_center, cluster_center + dim_new);
        
        for(i = 0; i < kk-1; i++)
            for(j = i+1; j < kk; j++){
                temp_dist = calc_dist_square(dim_new, cluster_center + i*dim_new,
                            cluster_center + j*dim_new);
                if(temp_dist < min_cl_dist)
                    min_cl_dist = temp_dist;
            } 
        // at this point we can determine the inter quantity
        inter = min_cl_dist;
        
        validity = intra / inter ;
        printf("kk = %d, Validity = %lf, SSE = %lf, Iters = %d\n", 
                kk, validity, sse_total, kmean_iters);

        kk++;

        free(cluster_center); free(cluster_radius);
        free(cluster_start); free(cluster_size); free(cluster_ssd);
    }
	
	end_t = clock();
    run_time = (double) (end_t - start_t) / CLOCKS_PER_SEC;
    
    printf("\n***********************************\n");
	printf("Total elapsed time: %lf\n", run_time);
    printf("Total Iterations: %d\n", total_iterations);
    printf("\n***********************************\n");
    
    free(cluster_assign); free(datum);
    
    return 0;
}

//**********----- End of main()-----**************************